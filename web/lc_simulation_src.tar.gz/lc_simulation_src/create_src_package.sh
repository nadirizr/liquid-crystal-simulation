#!/bin/bash

# Prepare source directory.
rm -rf lc_simulation_src
svn export . lc_simulation_src
rm -rf lc_simulation_src/web
rm -rf lc_simulation_src/runs

# Create the source tar file.
tar -cvzf web/lc_simulation_src.tar.gz lc_simulation_src
rm -rf lc_simulation_src

# Prepare web directory.
rm -rf lc_simulation_web
mkdir lc_simulation_web
svn export ./web lc_simulation_web/web
svn export ./runs lc_simulation_web/runs
rm -f lc_simulation_web/web/lc_simulation_src.tar.gz lc_simulation_web/web/lc_simulation_web.tar.gz

# Create the web tar file.
tar -cvzf web/lc_simulation_web.tar.gz lc_simulation_web
rm -rf lc_simulation_web

# Commit the new file.
svn commit web/lc_simulation_src.tar.gz web/lc_simulation_web.tar.gz -m "New version of LCS sources and web."
